public class BigbenchClone{    
            public com.google.protobuf.RpcChannel getChannel() {
                return channel;
            }
}