public class BigbenchClone{    
            public RegisterableChannel getChannel() {
                return channel;
            }
}