public class BigbenchClone{    
    public String[] getChannelGroups() {
        return m_ChannelGroups;
    }
}