public class BigbenchClone{    
            public void run() {
                setChannelList(channelListRequest.getChannelList());
                reloadChannels.setEnabled(true);
            }
}