public class BigbenchClone{    
    public Channel getChannel(String channelName) {
        return metadataManager.getChannel(channelName);
    }
}