public class BigbenchClone{    
    public Channel getChannel() {
        throw new UnsupportedOperationException();
    }
}