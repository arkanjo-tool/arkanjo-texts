public class BigbenchClone{    
        public ChannelInfo[] getChannelInfos() {
            return null;
        }
}