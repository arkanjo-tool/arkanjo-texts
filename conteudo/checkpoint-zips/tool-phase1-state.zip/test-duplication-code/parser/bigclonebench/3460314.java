public class BigbenchClone{    
    public CueChannelLevel getChannelLevel(final int channelIndex) {
        return channelLevels.get(channelIndex);
    }
}