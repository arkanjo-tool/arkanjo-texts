public class BigbenchClone{    
    public void flushBuffer() {
        buffer = new double[getDataLayout().getChannelCount()][][];
    }
}