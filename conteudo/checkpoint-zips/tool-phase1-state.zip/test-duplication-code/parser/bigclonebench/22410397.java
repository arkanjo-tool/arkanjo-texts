public class BigbenchClone{    
    public long getChannel_count() {
        return pjsuaJNI.pjmedia_port_info_channel_count_get(swigCPtr, this);
    }
}