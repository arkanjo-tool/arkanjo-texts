public class BigbenchClone{    
    public void _write(org.omg.CORBA.portable.OutputStream o) {
        org.omg.CosNotifyChannelAdmin.ConnectionAlreadyActiveHelper.write(o, value);
    }
}