public class BigbenchClone{    
    public String getChannelName() {
        return mux.getChannel().getClusterName();
    }
}