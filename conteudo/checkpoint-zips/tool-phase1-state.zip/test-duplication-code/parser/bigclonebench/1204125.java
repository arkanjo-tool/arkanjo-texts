public class BigbenchClone{    
    public List<Channel> getChannels() {
        return channels;
    }
}