public class BigbenchClone{    
    public Long getChannelId() {
        return this.channelId;
    }
}