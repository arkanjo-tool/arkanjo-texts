public class BigbenchClone{    
    public void setTargetChannelId(String targetChannelId) {
        this.targetChannelId = targetChannelId;
    }
}