public class BigbenchClone{    
    public Channel getChannel() {
        return (m_channel);
    }
}