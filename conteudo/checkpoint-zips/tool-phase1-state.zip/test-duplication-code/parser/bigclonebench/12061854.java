public class BigbenchClone{    
    public String getChannelName() {
        return ch;
    }
}