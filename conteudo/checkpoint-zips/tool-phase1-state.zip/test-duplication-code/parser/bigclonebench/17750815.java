public class BigbenchClone{    
    public double getChannelNumber() {
        return channelNumber;
    }
}