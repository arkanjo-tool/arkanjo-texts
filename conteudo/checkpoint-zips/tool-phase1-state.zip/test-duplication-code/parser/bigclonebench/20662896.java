public class BigbenchClone{    
    public Channel getChannel(int id) {
        return Channels.get(id);
    }
}