public class BigbenchClone{    
        
        public ChannelType getChannelType() {
            return ChannelType.COUNTER;
        }
}