public class BigbenchClone{    
    public final Integer getChannelNum() {
        return channelNum;
    }
}