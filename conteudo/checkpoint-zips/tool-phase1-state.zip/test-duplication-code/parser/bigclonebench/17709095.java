public class BigbenchClone{    
    public OpenSearchRssChannel getChannel() {
        return m_channel;
    }
}