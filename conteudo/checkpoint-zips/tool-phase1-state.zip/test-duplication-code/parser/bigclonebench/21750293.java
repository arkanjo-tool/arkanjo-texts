public class BigbenchClone{    
    public int getChannelMode() {
        return channelMode;
    }
}