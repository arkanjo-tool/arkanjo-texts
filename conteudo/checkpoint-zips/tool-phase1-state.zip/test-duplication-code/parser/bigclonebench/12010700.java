public class BigbenchClone{    
    
    public void createPartControl(Composite parent) {
        createGraphicalViewer(parent);
    }
}