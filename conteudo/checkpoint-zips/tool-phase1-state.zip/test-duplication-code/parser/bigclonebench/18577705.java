public class BigbenchClone{    
    public String getInstallPath() {
        return GameDatabase.getInstallPath(roomData.getChannel());
    }
}