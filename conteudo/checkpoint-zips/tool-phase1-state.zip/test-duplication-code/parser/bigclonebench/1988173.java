public class BigbenchClone{    
    public int getChannelNumber() {
        return _channelNumber;
    }
}