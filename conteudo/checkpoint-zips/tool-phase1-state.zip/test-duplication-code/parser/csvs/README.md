Folder created to store intermediary csvs files to evaluate the tool in BigCloneEval
